export default function About(){
    return <div>
        <h1 className="alert-danger text-center m-5">About</h1>
    </div>
}