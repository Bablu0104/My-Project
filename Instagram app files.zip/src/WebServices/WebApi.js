export default  {
    registerAPI : "http://tutorials.codebetter.in:7084/auth/save",
    loginAPI : "http://tutorials.codebetter.in:7084/auth/login",
    loginUserInfo : "http://tutorials.codebetter.in:7084/api/user/me",
    userPic : "http://tutorials.codebetter.in:7084/api/user/uploadpic",
    updateUserInfo : " http://tutorials.codebetter.in:7084/api/user/update",
    updatePassword : "http://tutorials.codebetter.in:7084/api/user/changepassword",
    postList : "http://tutorials.codebetter.in:7084/api/post/list",
    userList : "http://tutorials.codebetter.in:7084/api/user/list",
    userPostSave : "http://tutorials.codebetter.in:7084/api/post/save",
    userPostList : " http://tutorials.codebetter.in:7084/api/post/mypost",
    saveComment : "http://tutorials.codebetter.in:7084/api/comment/save",
    msgSend : "http://tutorials.codebetter.in:7084/api/user/msg/send",
    specificUserMsg : "http://tutorials.codebetter.in:7084/api/user/msg/get/2"
}